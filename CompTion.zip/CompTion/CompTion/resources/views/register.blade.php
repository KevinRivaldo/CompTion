@extends('welcome')
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <img src="image/logo.png" alt="">
    @section('css')
        <link href="{{ asset('css/bgcolor.css') }}" rel="stylesheet">
    @endsection
</nav>  
<div class="container">
    <div class="container text-center ">
        <br>
        <h3> Register </h3>
    </div>
</div>
<br><br>

<div class="container">
    <center>
        <div class="shadow p-4 w-50 bg-white">
            <form>
                <div class="form-group row">
                    <label for="UserName" class="col-sm-3 col-form-label">UserName:</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="inputUsername"required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="Password"class="col-sm-3 col-form-label" >Password</label>
                    <div class="col-sm-7">
                        <input type="password" class="form-control" id="inputPassword"required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="Email"class="col-sm-3 col-form-label" >Email Address</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="inputEmail"required>
                    </div>
                </div>
                <button type="submit" class="btn btn-danger">Register</button>
                <a class="btn btn-danger" href="login">Login&nbsp;</a>
            </form>
    </center>
</div>
</div>