<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
    
</body>
</html><?php /**PATH C:\Users\MSI\Desktop\CompTion\resources\views/welcome.blade.php ENDPATH**/ ?>